package com.example.servicea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceaApplicationTests {

	@Test
	void contextLoads() {
	}

}
